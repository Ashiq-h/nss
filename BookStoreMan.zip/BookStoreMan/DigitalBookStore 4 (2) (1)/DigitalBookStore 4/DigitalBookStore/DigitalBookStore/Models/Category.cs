﻿using System.ComponentModel.DataAnnotations;

namespace DigitalBookStore.Models
{
    public class Category
    {
        [Key]
        public required int CategoryID { get; set; }
        public required string Name { get; set; }
        public ICollection<Book>? book { get; set; }
    }
}
