﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalBookStore.Models
{
    public class Book
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int BookID { get; set; }
        public required string Title { get; set; }
        public required double Price { get; set; }
        public required int StockQuantity { get; set; }
        public required string ImageUrl { get; set; }

        // Foreign Key
        [ForeignKey(nameof(Author))]
        public int AuthorID { get; set; }

        [ForeignKey(nameof(Category))]
        public int CategoryID { get; set; }

        // Navigation Property
        public Author? Author { get; set; }  // Check Required or ? or Ignore the warning
        public Category? Category { get; set; }
    }
}
