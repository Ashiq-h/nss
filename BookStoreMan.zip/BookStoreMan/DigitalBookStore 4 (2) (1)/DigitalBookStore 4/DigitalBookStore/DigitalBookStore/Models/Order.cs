﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalBookStore.Models
{
    public class Order
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int OrderID { get; set; }
        public required DateTime OrderDate { get; set; }
        public required double TotalAmount {get; set;}
        public required OrderStatus Status { get; set; }
       // [ForeignKey(nameof(User))]
       // public required int UserID { get; set; }
       // public User User { get; set; }
        public List<BookOrder>? OrderedBooks { get; set; } // ✅ Stores multiple book
        public static implicit operator OrderStatus(Order v)
        {
            throw new NotImplementedException();
        }

        public required string Name { get; set; }
        public required string Email { get; set; }
        public required string ShippingAddress { get; set; }
        public required string PaymentMode { get; set; }
        public required long PhoneNumber { get; set; }

    }

    public enum OrderStatus
    {
        Pending,
        Shipped,
        Delivered
    }
}
