﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalBookStore.Models
{
    public class BookOrder
    {
        [Key]
        public int BookOrderID { get; set; }
        public required int OrderID { get; set; }
        public required int BookID { get; set; }
        public required int Quantity { get; set; }

        [ForeignKey(nameof(OrderID))]
        public Order? Order { get; set; }

        [ForeignKey(nameof(BookID))]
        public Book? Book { get; set; }
    }
}
