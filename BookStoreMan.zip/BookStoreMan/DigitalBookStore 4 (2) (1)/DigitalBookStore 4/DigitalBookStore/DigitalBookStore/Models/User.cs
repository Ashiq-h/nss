﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DigitalBookStore.Models
{
    public class User
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserID { get; set; }
        public required string Name { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public required string Email { get; set; }
        public required string Password { get; set; }
        public required string Role { get; set; }
        public required string Review { get; set; }
        public ICollection<Review>? Reviews { get; set; }
       // public ICollection<Order>? Orders { get; set; }
    }
}
