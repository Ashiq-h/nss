﻿namespace DigitalBookStore.DTO
{
    public class AuthorDTO
    {
        public required int AuthorID { get; set; }
        public required string Name { get; set; }
    }
}
