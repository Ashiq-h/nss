﻿using System.ComponentModel.DataAnnotations;

namespace DigitalBookStore.DTO
{
    public class LoginUserDTO
    {
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public required string Email { get; set; }
        public required string Password { get; set; }
    }
}
