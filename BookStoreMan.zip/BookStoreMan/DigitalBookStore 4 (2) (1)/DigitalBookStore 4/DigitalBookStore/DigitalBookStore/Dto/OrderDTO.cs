﻿using DigitalBookStore.Models;
using DigitalBookStore.DTO;

namespace DigitalBookStore.DTO
{
    public class OrderDTO
    {
        public int OrderID { get; set; }
        public required DateTime OrderDate { get; set; }
        public required double TotalAmount { get; set; }
        public required OrderStatus Status { get; set; }

       // public int UserID { get; set; }
        public List<BookOrderDTO> OrderedBooks { get; set; } = new();

        public required string Name { get; set; }
        public required string Email { get; set; }
        public required string ShippingAddress { get; set; }
        public required string PaymentMode { get; set; }
        public required long PhoneNumber { get; set; }
    }

    public class BookOrderDTO
    {
        public int BookID { get; set; }
        public int Quantity { get; set; }
    }

}
