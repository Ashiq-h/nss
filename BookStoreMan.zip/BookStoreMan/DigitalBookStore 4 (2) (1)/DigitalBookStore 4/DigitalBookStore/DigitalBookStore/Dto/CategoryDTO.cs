﻿namespace DigitalBookStore.DTO
{
    public class CategoryDTO
    {
        public required int CategoryID { get; set; }
        public required string Name { get; set; }
    }
}
