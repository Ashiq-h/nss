﻿using DigitalBookStore.DTO;

namespace DigitalBookStore.Repositories.Interface
{
    public interface ICategoryRepository
    {
        Task AddCategoryAsync(CategoryDTO categorydto);

    }
}
