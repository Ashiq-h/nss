﻿using DigitalBookStore.Models;
//using DigitalBookStore.Models;
using static DigitalBookStore.Models.Order;

//using DigitalBookStore.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace DigitalBookStore.Repositories.Interface
{
    public interface IOrderRepository
    {
        Task<IEnumerable<Order>> GetOrders();
        Task<Order?> GetOrderById(int id);
        Task<Order> CreateOrder(Order order);
        Task<bool> UpdateOrderStatus(int id, OrderStatus status);
        Task<bool> DeleteOrder(int orderId);

        // ✅ New methods
        Task<Book?> GetBookByIdAsync(int bookId);
        Task<bool> UpdateBookAsync(int bookId, Book book);
    }
}

