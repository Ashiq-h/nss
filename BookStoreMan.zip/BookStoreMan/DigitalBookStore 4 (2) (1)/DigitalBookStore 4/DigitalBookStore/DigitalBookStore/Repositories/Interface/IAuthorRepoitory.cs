﻿using DigitalBookStore.DTO;

namespace DigitalBookStore.Repositories.Interface

{
    public interface IAuthorRepository
    {
        Task AddAuthorAsync(AuthorDTO authordto);
    }
}
