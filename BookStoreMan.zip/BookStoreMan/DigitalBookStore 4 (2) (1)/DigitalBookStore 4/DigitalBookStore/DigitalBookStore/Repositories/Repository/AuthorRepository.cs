﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;

using Microsoft.EntityFrameworkCore;

namespace DigitalBookstoreManagementSystem.Repositories.Repository
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly DigitalBookStoreDBContext _context;
        public AuthorRepository(DigitalBookStoreDBContext context)
        {
            _context = context;
        }
        public async Task AddAuthorAsync(AuthorDTO authordto)
        {
            var author = new Author
            {
                AuthorID = 0,
                Name = authordto.Name,
            };
            if (authordto != null)
            {
                await _context.Authors.AddAsync(author);
                await _context.SaveChangesAsync();
            }
        }
    }
}
