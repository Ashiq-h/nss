﻿using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;

using Microsoft.EntityFrameworkCore;
using static DigitalBookStore.Models.Order;

namespace DigitalBookstoreManagementSystem.Repositories.Repository
{
    public class OrderRepository : IOrderRepository
    {
        private readonly DigitalBookStoreDBContext _context;

        public OrderRepository(DigitalBookStoreDBContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Order>> GetOrders()
        {
            return await _context.Orders.ToListAsync();
        }
        public async Task<Order?> GetOrderById(int id)
        {
            return await _context.Orders.FindAsync(id);
        }
        public async Task<Order> CreateOrder(Order order)
        {
            _context.Orders.Add(order);
            await _context.SaveChangesAsync(); // Save the order first

            if (order.OrderedBooks != null && order.OrderedBooks.Any())
            {
                foreach (var bookOrder in order.OrderedBooks)
                {
                    var newBookOrder = new BookOrder
                    {
                        OrderID = order.OrderID,
                        BookID = bookOrder.BookID,
                        Quantity = bookOrder.Quantity
                    };

                    _context.BookOrders.Add(newBookOrder); // ✅ Add ordered books
                }

                await _context.SaveChangesAsync(); // Save the book orders
            }

            return order;
        }


        public async Task<bool> UpdateOrderStatus(int id, OrderStatus status)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null) return false;

            order.Status = status;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteOrder(int orderId)
        {
            var order = await _context.Orders.FindAsync(orderId);
            if (order == null)
                return false;  //order is not found

            _context.Orders.Remove(order);
            await _context.SaveChangesAsync();
            return true;  //deleted successfullyy
        }
        public async Task<bool> UpdateBook(Book book)
{
    _context.Books.Update(book);
    await _context.SaveChangesAsync();
    return true;
}
        public async Task<Book?> GetBookByIdAsync(int bookId)
        {
            return await _context.Books.FindAsync(bookId);
        }

        public async Task<bool> UpdateBookAsync(int bookId, Book updatedBook)
        {
            var book = await _context.Books.FindAsync(bookId);
            if (book == null) return false;

            book.StockQuantity = updatedBook.StockQuantity;
            await _context.SaveChangesAsync();
            return true;
        }


    }
}
