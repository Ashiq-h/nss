﻿using DigitalBookStore.Models;
using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DigitalBookStore.Controllers.CRUDControllers
{
    [Route("api/[controller]")]
    [ApiController]
  //  [Authorize(Roles = "Admin")]

    public class CategoryController : ControllerBase
    {
        private readonly ICategoryRepository _categoryRepository;

        public CategoryController(ICategoryRepository categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }
        [HttpPost]
        public async Task<ActionResult<Category>> AddCategoryAsync([FromBody] CategoryDTO categorydto)

        {
            if (categorydto == null)
            {
                return BadRequest("Invalid Data");
            }

            await _categoryRepository.AddCategoryAsync(categorydto);
            return Ok(categorydto);
        }
    }
}

