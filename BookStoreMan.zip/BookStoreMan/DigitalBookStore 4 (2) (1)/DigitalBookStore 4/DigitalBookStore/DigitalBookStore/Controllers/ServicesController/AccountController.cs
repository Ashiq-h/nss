﻿using DigitalBookStore.DTO;
using DigitalBookStore.Services.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DigitalBookStore.Controllers.ServiceControllers
{
    [Route("api/[controller]")]
    [ApiController]
   
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _userService;
        public AccountController(IAccountService userservice)
        {
            _userService = userservice;
        }

        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginUserDTO logindto)
        {
            var user = await _userService.ValidateUser(logindto); // Validate User
            if (user is null)
            {
                return Unauthorized(new { Message = "Oops! You cannot access the resource" });
            }

            var token = await _userService.AuthenticateUser(logindto);
            return Ok(new { token = token, role = user.Role }); // ✅ Send token & role
        }


        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterUserDTO userdto)
        {
            if (userdto == null)
            {
                return BadRequest("User Data is missing!");
            }
            var result = await _userService.RegisterUser(userdto);

            return Ok(new { Message = "User Registered. Please Login!!" });
        }
    }
}