﻿using DigitalBookStore.DTO;

using DigitalBookStore.Models;
namespace DigitalBookStore.Services.Interface
{
    public interface IAccountService
    {
        Task<bool> RegisterUser(RegisterUserDTO userdto);

        Task<string> AuthenticateUser(LoginUserDTO logindto); // String because jwt token returned after login

        Task<User?> ValidateUser(LoginUserDTO logindto);
    }
}
