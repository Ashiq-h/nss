﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;


namespace DigitalBookStore.Services.Interface
{
    public interface IBookService
    {
        Task<IEnumerable<Book>> GetAllBooksAsync();
        Task<Book> GetBookByIdAsync(int id);
        Task<Book> AddBookAsync(BookDTO bookdto);
        Task UpdateBookAsync(int id, BookDTO bookdto);
        Task DeleteBookAsync(int id);
    }
}
