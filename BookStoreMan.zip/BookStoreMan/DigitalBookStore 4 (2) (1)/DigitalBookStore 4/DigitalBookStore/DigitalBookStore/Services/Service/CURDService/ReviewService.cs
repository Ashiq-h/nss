﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;

using DigitalBookstoreManagementSystem.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace DigitalBookStore.Services.Service.CRUDService
{
    public class ReviewService : IReviewService
    {
        private readonly IReviewRepository _reviewRepository;

        public ReviewService(IReviewRepository reviewRepository)
        {
            _reviewRepository = reviewRepository;
        }

        public async Task<IEnumerable<Review>> GetAllReviewsAsync()
        {
            return await _reviewRepository.GetAllReviewsAsync();
        }

        public async Task<Review> GetReviewByIdAsync(int id)
        {
            return await _reviewRepository.GetReviewByIdAsync(id);
        }

        public async Task<Review> AddReviewAsync(ReviewDTO reviewdto)
        {
            var review = new Review
            {
                ReviewID = reviewdto.ReviewID,
                Rating = reviewdto.Rating,
                Comment = reviewdto.Comment,
                BookID = reviewdto.BookID,
                UserID = reviewdto.UserID,
                Comments = "Your comments here" // Add this line to set the required Comments property
            };
            return await _reviewRepository.AddReviewAsync(review);
        }

        public async Task UpdateReviewAsync(int id, ReviewDTO reviewdto)
        {
            var review = new Review
            {
                ReviewID = reviewdto.ReviewID,
                Rating = reviewdto.Rating,
                Comment = reviewdto.Comment,
                BookID = reviewdto.BookID,
                UserID = reviewdto.UserID,
                Comments = "Your comments here" // Add this line to set the required Comments property
            };
            await _reviewRepository.UpdateReviewAsync(id, review);
        }

        public async Task DeleteReviewAsync(int id)
        {
            await _reviewRepository.DeleteReviewAsync(id);
        }
    }
}
