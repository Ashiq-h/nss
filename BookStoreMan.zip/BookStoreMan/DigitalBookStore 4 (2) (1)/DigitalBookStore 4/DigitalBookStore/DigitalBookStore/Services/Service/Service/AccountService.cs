﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;
//using DigitalBookStore.Models;
//using DigitalBookStore.Repositories.Interface;
using DigitalBookstoreManagementSystem.Services.Interface;
using Microsoft.AspNetCore.Identity;
using DigitalBookStore.Services.Interface;
using DigitalBookstoreManagementSystem.Repositories.Repository;

namespace DigitalBookstoreManagementSystem.Services.Service.Service
{
    public class AccountService : IAccountService
    {
        private readonly IUserRepository userRepository;
        private readonly ITokenRepository tokenRepository;

        public AccountService(IUserRepository userRepository, ITokenRepository tokenRepository)
        {
            this.userRepository = userRepository;
            this.tokenRepository = tokenRepository;
        }

        public async Task<string> AuthenticateUser(LoginUserDTO logindto)
        {
            var user = await userRepository.GetUserByEmailAsync(logindto.Email);
            if (user == null || logindto.Password != user.Password)
            {
                return null;
            }

            var roles = new List<string> { user.Role };

            var token = tokenRepository.CreateJWTToken(new IdentityUser { Email = user.Email }, roles);

            return token;
        }

        public async Task<bool> RegisterUser(RegisterUserDTO userdto)
        {
            if (userdto == null)
            {
                return false;
            }
            var user = new User
            {
                UserID = 0,
                Name = userdto.Name,
                Email = userdto.Email,
                Password = userdto.Password,
                Role = userdto.Role,
                Review = "Your review text here" // Add this line to set the required Review property
            };

            await userRepository.AddUserAsync(user);
            return true;
        }
        public async Task<User?> ValidateUser(LoginUserDTO loginDto)
        {
            var user = await userRepository.GetUserByEmailAsync(loginDto.Email);
            
            return user;
            // User not found or invalid password
        }
    }
}
