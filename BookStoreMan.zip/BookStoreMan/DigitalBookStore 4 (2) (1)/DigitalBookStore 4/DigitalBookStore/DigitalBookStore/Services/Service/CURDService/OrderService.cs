﻿using DigitalBookStore.DTO;
using DigitalBookStore.Models;
using DigitalBookStore.Repositories.Interface;

using DigitalBookStore.Services.Interface;
using DigitalBookstoreManagementSystem.Repositories.Repository;
using DigitalBookstoreManagementSystem.Services.Interface;
using Microsoft.EntityFrameworkCore;

namespace DigitalBookstoreManagementSystem.Services.Service.CRUDService
{
    public class OrderService : IOrderService
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IBookRepository _bookRepository; // Add this

        public OrderService(IOrderRepository orderRepository, IBookRepository bookRepository)
        {
            _orderRepository = orderRepository;
            _bookRepository = bookRepository; // Initialize it
        }


        public async Task<IEnumerable<Order>> GetOrders()
        {
            return await _orderRepository.GetOrders();
        }
        public async Task<Order?> GetOrderById(int id)
        {
            return await _orderRepository.GetOrderById(id);
        }
        public async Task<Order> CreateOrder(OrderDTO orderdto)
        {
            var order = GetOrder(orderdto);
            var createdOrder = await _orderRepository.CreateOrder(order);

            foreach (var bookOrder in orderdto.OrderedBooks)
            {
                var book = await _orderRepository.GetBookByIdAsync(bookOrder.BookID);
                if (book != null && book.StockQuantity >= bookOrder.Quantity)
                {
                    book.StockQuantity -= bookOrder.Quantity;
                    await _orderRepository.UpdateBookAsync(book.BookID, book);
                }
                else
                {
                    throw new Exception($"Insufficient stock for Book ID {bookOrder.BookID}");
                }
            }
            return createdOrder;
        }
        


        private static Order GetOrder(OrderDTO orderdto)
        {
            return new Order { OrderID = orderdto.OrderID, OrderDate = orderdto.OrderDate, TotalAmount = orderdto.TotalAmount, Status = orderdto.Status, Name = orderdto.Name, Email=orderdto.Email, PaymentMode=orderdto.PaymentMode, ShippingAddress=orderdto.ShippingAddress, PhoneNumber=orderdto.PhoneNumber};
        }

        public async Task<bool> UpdateOrderStatus(int id, OrderStatus status)
        {
            return await _orderRepository.UpdateOrderStatus(id, status);

        }
        public async Task<bool> DeleteOrder(int orderId)
        {
            return await _orderRepository.DeleteOrder(orderId);
        }

        public async Task<Book?> GetBookByIdAsync(int bookId)
        {
            return await _bookRepository.GetBookByIdAsync(bookId);
        }

        public async Task<bool> UpdateBookQuantityAsync(Book book)
        {
            return await _bookRepository.UpdateBookAsync(book.BookID, book); // ✅ Now correctly returning bool
        }


    }
}

